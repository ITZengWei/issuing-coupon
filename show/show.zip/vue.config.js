module.exports = {
  publicPath: './',
}
