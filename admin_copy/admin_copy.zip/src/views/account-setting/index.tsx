import { FC } from 'react'

const AccountSetting: FC = (props: any) => {
  return <div>AccountSetting</div>
}

export default AccountSetting
