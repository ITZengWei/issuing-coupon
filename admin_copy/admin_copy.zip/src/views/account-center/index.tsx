import { FC } from 'react'

const AccountCenter: FC = (props: any) => {
  return <div>AccountCenter</div>
}

export default AccountCenter
