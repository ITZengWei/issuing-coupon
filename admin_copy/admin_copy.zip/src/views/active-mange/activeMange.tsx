import * as React from 'react'

interface IActiveMangeProps {}

const ActiveMange: React.FC<IActiveMangeProps> = props => {
  return <div>活动管理</div>
}

export default ActiveMange
