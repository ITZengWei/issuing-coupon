import { FC } from 'react'

const PlatformCoupon: FC = (props: any) => {
  return <div>PlatformCoupon</div>
}

export default PlatformCoupon
