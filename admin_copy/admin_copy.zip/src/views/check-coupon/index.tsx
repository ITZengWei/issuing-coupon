import { FC } from 'react'

const CheckCoupon: FC = (props: any) => {
  return <div>CheckCoupon</div>
}

export default CheckCoupon
